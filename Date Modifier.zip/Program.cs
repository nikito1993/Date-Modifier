﻿namespace Date_Modifier
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            string firstDate=Console.ReadLine();
            string secondDate=Console.ReadLine();

            Console.WriteLine(DateModifier.diferences(firstDate,secondDate));
        }
    }
}