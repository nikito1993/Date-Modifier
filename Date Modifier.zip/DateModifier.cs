﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Date_Modifier
{
     public class DateModifier
    {
        public static int diferences(string startDate, string endDate)
        {
            DateTime startDateNew = DateTime.Parse(startDate);
            DateTime endDateNew=DateTime.Parse(endDate);

            TimeSpan TotalDiferences=endDateNew - startDateNew;
            return Math.Abs(TotalDiferences.Days);
        }
    }
}
